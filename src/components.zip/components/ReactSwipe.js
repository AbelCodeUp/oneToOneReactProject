import React from 'react';
import ReactDOM from 'react-dom';
import { Link } from 'react-router';
import axios from 'axios';
import ServerUrl from '../config/server';
import Swiper from 'swiper';
require('../common/swiper/swiper.min.css');

export default class OrderLesson extends React.Component {
    constructor() {
        super()
        this.state = {

        }
    }
    componentDidMount() {
        
    }

    render() {
        return (
            <div>
               person
            </div>
        )
    }
}
